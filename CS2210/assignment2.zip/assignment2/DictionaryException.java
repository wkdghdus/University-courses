
public class DictionaryException extends RuntimeException 
{
	public DictionaryException()
	{
		super ("Dictionary Error");
	}
}
