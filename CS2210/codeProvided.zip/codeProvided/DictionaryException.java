public class DictionaryException extends Exception {
  public DictionaryException(String mssg) {
    super(mssg);
  }
}
