public class MultimediaException extends Exception {
  public MultimediaException(String mssg) {
    super(mssg);
  }
}
